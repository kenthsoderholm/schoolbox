------------------------------------------------------
* Kryptera lösen vid registring.
* Forgot password - Kenth
* (Remember me) - Kenth
* Singel and dubbelklick(Prio)
* Sökfältet
* Fixa rightclick för tabell.
* Lägg till i footern
	- About
	- Contact
	- Terms

Efter börja med file upload and mapping


* = Vid tid över
------------------------------------------------------